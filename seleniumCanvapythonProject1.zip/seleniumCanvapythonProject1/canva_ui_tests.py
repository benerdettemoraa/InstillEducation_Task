# This is a sample Python script.

# Press ⌃R to execute it or replace it with your code.
# Press Double ⇧ to search everywhere for classes, files, tool windows, actions, and settings.


from selenium import webdriver
from selenium.webdriver.common.by import By
#Navigate to the canva site
browser = webdriver.Firefox()
browser.maximize_window()
browser.get('https://www.canva.com/en_gb/')
browser.set_page_load_timeout(120)

#Click the signup button
button_element = browser.find_element(By.XPATH,"//div[@id='root']/div/div[4]/div/div[2]/div/header/div[6]/button[2]/span")
button_element.click();

#Choose the Continue with email option

button_element = browser.find_element(By.XPATH,"//button[3]/span[2]")
button_element.click();

#Enter the email
your_email =browser.find_element(By.XPATH,"//input")
your_email.send_keys("stest9990097@gmail.com")

#Click on the continue button
button_element = browser.find_element(By.CSS_SELECTOR,".ubW6qw > .\_38oWvQ")
button_element.click();

#Click on Create Account
button_element = browser.find_element(By.XPATH,"//button/span")
button_element.click();

browser.quit()


# See PyCharm help at https://www.jetbrains.com/help/pycharm/
